package com.example.inspirese.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.inspirese.R
import com.example.inspirese.data.Tip
import com.example.inspirese.databinding.ItemTipBinding

/** Lista de dicas da aba Dicas, já filtrada pela categoria escolhida nas abas. */
class TipsAdapter(private val onClick: (Tip) -> Unit) :
    RecyclerView.Adapter<TipsAdapter.ViewHolder>() {

    private var items: List<Tip> = emptyList()

    fun submitList(newItems: List<Tip>) {
        items = newItems
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemTipBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTipBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tip = items[position]
        holder.binding.tvTipIcon.text = tip.emoji
        holder.binding.tvTipIcon.setBackgroundResource(
            if (tip.category == Tip.CAT_MENTAL) R.drawable.bg_chip_mental else R.drawable.bg_chip_bemestar
        )
        holder.binding.tvTipTitle.text = tip.title
        holder.binding.tvTipSummary.text = tip.summary
        holder.binding.rootTip.setOnClickListener { onClick(tip) }
    }

    override fun getItemCount() = items.size
}
