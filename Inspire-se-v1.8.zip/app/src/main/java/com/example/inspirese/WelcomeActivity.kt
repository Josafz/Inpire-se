package com.example.inspirese

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.inspirese.databinding.ActivityWelcomeBinding

/**
 * Primeira tela que a pessoa vê ao abrir o app. É só uma porta de entrada: não guarda
 * nada, não tem lógica — por isso não tem teste próprio. "Começar" leva para a Home e
 * fecha esta tela (finish()), então o botão "voltar" não traz a pessoa de volta pra ela.
 */
class WelcomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnStart.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
