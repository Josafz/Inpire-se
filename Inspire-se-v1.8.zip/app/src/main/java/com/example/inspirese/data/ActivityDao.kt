package com.example.inspirese.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ActivityDao {

    @Insert
    suspend fun insert(entry: ActivityEntry): Long

    @Query("UPDATE activity_entries SET durationSec = :sec WHERE id = :id")
    suspend fun updateDuration(id: Long, sec: Int)

    @Query("DELETE FROM activity_entries")
    suspend fun deleteAll()

    @Query("SELECT * FROM activity_entries ORDER BY timestamp DESC")
    suspend fun getAll(): List<ActivityEntry>
}
