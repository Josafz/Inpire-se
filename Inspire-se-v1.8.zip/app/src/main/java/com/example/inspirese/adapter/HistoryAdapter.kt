package com.example.inspirese.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.inspirese.R
import com.example.inspirese.data.ActivityEntry
import com.example.inspirese.databinding.ItemHistoryBinding
import com.example.inspirese.databinding.ItemHistoryHeaderBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Uma linha da lista do Histórico: ou um cabeçalho de data, ou uma atividade. */
sealed class HistoryRow {
    data class Header(val label: String) : HistoryRow()
    data class Entry(val activity: ActivityEntry) : HistoryRow()
}

private const val TYPE_HEADER = 0
private const val TYPE_ENTRY = 1

/** Lista agrupada por data (Hoje / Ontem / data), com um ícone colorido por tipo de atividade. */
class HistoryAdapter(private val onClick: (ActivityEntry) -> Unit) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<HistoryRow> = emptyList()
    private val timeFmt = SimpleDateFormat("HH:mm", Locale("pt", "BR"))

    fun submitList(newRows: List<HistoryRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    class HeaderHolder(val binding: ItemHistoryHeaderBinding) : RecyclerView.ViewHolder(binding.root)
    class EntryHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun getItemViewType(position: Int) = when (rows[position]) {
        is HistoryRow.Header -> TYPE_HEADER
        is HistoryRow.Entry -> TYPE_ENTRY
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_HEADER) {
            HeaderHolder(ItemHistoryHeaderBinding.inflate(inflater, parent, false))
        } else {
            EntryHolder(ItemHistoryBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is HistoryRow.Header -> (holder as HeaderHolder).binding.root.text = row.label
            is HistoryRow.Entry -> bindEntry((holder as EntryHolder).binding, row.activity)
        }
    }

    private fun bindEntry(binding: ItemHistoryBinding, item: ActivityEntry) {
        val (chipBg, icon) = when (item.type) {
            ActivityEntry.TYPE_BREATHING -> R.drawable.bg_chip_breathing to R.drawable.ic_sos
            ActivityEntry.TYPE_CHAT -> R.drawable.bg_chip_chat to R.drawable.ic_chat
            else -> R.drawable.bg_chip_tip to R.drawable.ic_tips
        }
        binding.iconChip.setBackgroundResource(chipBg)
        binding.ivItemIcon.setImageResource(icon)

        binding.tvItemLabel.text = item.label
        val time = timeFmt.format(Date(item.timestamp))
        binding.tvItemTime.text = if (item.durationSec > 0) {
            "$time · ${formatDuration(item.durationSec)}"
        } else {
            time
        }
        binding.root.setOnClickListener { onClick(item) }
    }

    private fun formatDuration(sec: Int): String {
        val minutes = TimeUnit.SECONDS.toMinutes(sec.toLong())
        return if (minutes < 1) "menos de 1 min" else "$minutes min"
    }

    override fun getItemCount() = rows.size
}
