package com.example.inspirese

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.inspirese.data.ActivityEntry
import com.example.inspirese.data.AppDatabase
import com.example.inspirese.data.Tips
import com.example.inspirese.databinding.ActivityTipDetailBinding
import com.example.inspirese.databinding.ItemTipStepBinding
import kotlinx.coroutines.launch

/** Tela de detalhe de uma dica: título, texto de abertura e passos numerados. */
class TipDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TIP_ID = "tip_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityTipDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val tipId = intent.getStringExtra(EXTRA_TIP_ID)
        val tip = Tips.byId(tipId) ?: Tips.all.first()

        binding.tvDetailIcon.text = tip.emoji
        binding.tvDetailTitle.text = tip.title
        binding.tvDetailBody.text = tip.body

        tip.steps.forEachIndexed { index, step ->
            val stepBinding = ItemTipStepBinding.inflate(LayoutInflater.from(this), binding.llSteps, false)
            stepBinding.tvStepNumber.text = (index + 1).toString()
            stepBinding.tvStepText.text = step
            binding.llSteps.addView(stepBinding.root)
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.btnVoltar.setOnClickListener { finish() }

        // Registra no histórico que esta dica foi aberta (não é uma métrica de leitura
        // de verdade, só marca que a pessoa abriu a tela).
        lifecycleScope.launch {
            AppDatabase.getInstance(this@TipDetailActivity).activityDao().insert(
                ActivityEntry(
                    type = ActivityEntry.TYPE_TIP,
                    label = "Dica lida: ${tip.title}",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }
}
