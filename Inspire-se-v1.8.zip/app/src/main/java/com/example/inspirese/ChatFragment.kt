package com.example.inspirese

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.inspirese.adapter.ChatAdapter
import com.example.inspirese.chat.AiClient
import com.example.inspirese.chat.AiConfig
import com.example.inspirese.chat.CrisisDetector
import com.example.inspirese.chat.OfflineResponder
import com.example.inspirese.data.ActivityEntry
import com.example.inspirese.data.AppDatabase
import com.example.inspirese.data.ChatMessage
import com.example.inspirese.databinding.FragmentChatBinding
import com.example.inspirese.util.Prefs
import kotlinx.coroutines.launch
import java.util.Calendar

private const val CRISIS_REPLY =
    "Sinto muito que você esteja passando por isso. Você não precisa enfrentar isso sozinho(a). " +
        "Por favor, fale com alguém agora: CVV 188 (24 horas, gratuito). Em emergência, SAMU 192."

/**
 * Chat de texto livre. Sem botões de resposta rápida — é só escrever e enviar, igual a
 * qualquer app de mensagens.
 *
 *  - Texto de crise nunca é respondido pelo OfflineResponder nem pela IA: cai direto na
 *    resposta fixa de CVV/SAMU (CrisisDetector decide isso).
 *  - Sem a IA ligada (padrão, 100% offline): quem responde é o OfflineResponder — não é IA
 *    de verdade, são respostas fixas escolhidas por palavra-chave.
 *  - Com a IA ligada (opcional, pede internet + aceite do usuário): quem responde é o AiClient,
 *    via proxy — e leva junto um resuminho do humor mais recente (só se for de hoje), para a
 *    resposta vir mais sintonizada com como a pessoa está, sem mandar nenhum outro dado pessoal.
 *
 * O cabeçalho é enxuto (← Conversa · SOS · ⋮): ligar/desligar a IA e limpar a conversa viram
 * itens do menu ⋮ (btn_more) em vez de ocuparem espaço fixo na tela.
 */
class ChatFragment : Fragment() {

    private var _binding: FragmentChatBinding? = null
    private val binding get() = _binding!!

    private val adapter = ChatAdapter()
    private var busy = false   // evita duplo envio enquanto uma resposta está em andamento
    private var aiMode = false

    // Marca a janela desta visita à aba Conversa, só para registrar no Histórico (ver onDestroyView).
    private var sessionStart = 0L
    private var sentAnyThisSession = false

    private val chatDao get() = AppDatabase.getInstance(requireContext()).chatDao()
    private val moodDao get() = AppDatabase.getInstance(requireContext()).moodDao()
    private val activityDao get() = AppDatabase.getInstance(requireContext()).activityDao()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvChat.layoutManager = LinearLayoutManager(requireContext())
        binding.rvChat.adapter = adapter

        binding.btnBack.setOnClickListener {
            (activity as? MainActivity)?.selectTab(R.id.nav_home)
        }
        binding.btnChatSos.setOnClickListener {
            startActivity(Intent(requireContext(), SosActivity::class.java))
        }
        binding.btnMore.setOnClickListener { showMoreMenu() }
        binding.btnSend.setOnClickListener { sendMessage() }

        sessionStart = System.currentTimeMillis()
        sentAnyThisSession = false

        loadConversation()
    }

    private fun loadConversation() {
        viewLifecycleOwner.lifecycleScope.launch {
            val saved = chatDao.getAll()
            adapter.setAll(saved)
            scrollToEnd()

            val ctx = requireContext()
            aiMode = AiConfig.isConfigured(ctx) && Prefs.aiConsent(ctx) && Prefs.aiEnabled(ctx)
            applyAiUi()

            if (saved.isEmpty()) {
                addMessage(
                    ChatMessage.ROLE_BOT,
                    "Olá! Sou o assistente do Inspire-se. Pode me contar como você está?"
                )
            }
        }
    }

    private suspend fun addMessage(role: String, text: String) {
        val message = ChatMessage(role = role, text = text, timestamp = System.currentTimeMillis())
        val id = chatDao.insert(message)
        adapter.add(message.copy(id = id))
        scrollToEnd()
    }

    private fun scrollToEnd() {
        if (adapter.itemCount > 0) binding.rvChat.scrollToPosition(adapter.itemCount - 1)
    }

    // ------------------------------------------------------------------ menu ⋮ (substitui a chave e o botão antigos)

    private fun showMoreMenu() {
        val ctx = requireContext()
        val popup = PopupMenu(ctx, binding.btnMore)
        val aiId = 1
        val clearId = 2
        val serverId = 3

        // "Ligar" só aparece depois que há um servidor configurado; "Configurar" aparece sempre.
        if (AiConfig.isConfigured(ctx)) {
            popup.menu.add(0, aiId, 0, if (aiMode) "Desligar IA online" else "Ligar IA online")
        }
        popup.menu.add(0, serverId, 1, "Configurar servidor da IA")
        popup.menu.add(0, clearId, 2, "Limpar conversa")

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                aiId -> {
                    if (aiMode) setAiMode(false) else tryEnableAi()
                    true
                }
                serverId -> {
                    showAiServerDialog()
                    true
                }
                clearId -> {
                    confirmClear()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    // ------------------------------------------------------------------ envio de mensagem

    private fun sendMessage() {
        val text = binding.etMessage.text.toString().trim()
        if (text.isEmpty()) {
            binding.etMessage.error = "Escreva algo primeiro"
            return
        }
        if (busy) return
        busy = true
        sentAnyThisSession = true
        binding.etMessage.text.clear()

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                addMessage(ChatMessage.ROLE_USER, text)

                if (CrisisDetector.isCrisis(text)) {
                    addMessage(ChatMessage.ROLE_BOT, CRISIS_REPLY)   // nunca passa pelo OfflineResponder nem pela IA
                } else if (aiMode) {
                    askAi()
                } else {
                    addMessage(ChatMessage.ROLE_BOT, OfflineResponder.reply(text))
                }
            } finally {
                busy = false
            }
        }
    }

    private suspend fun askAi() {
        val ctx = requireContext()
        if (!AiClient.isOnline(ctx)) {
            addMessage(ChatMessage.ROLE_BOT, "Estou sem internet agora. Voltei para o modo offline.")
            setAiMode(false)
            return
        }
        binding.tvTyping.visibility = View.VISIBLE
        try {
            val history = chatDao.getLast(12).reversed()   // getLast vem do mais novo; a IA quer do mais antigo
            addMessage(ChatMessage.ROLE_BOT, AiClient.reply(ctx, history, recentMoodContext()))
        } catch (e: AiClient.AiException) {
            addMessage(ChatMessage.ROLE_BOT, e.message ?: "Não consegui falar com a IA agora. Voltei para o modo offline.")
            setAiMode(false)
        } finally {
            _binding?.tvTyping?.visibility = View.GONE   // a tela pode já ter sido fechada
        }
    }

    /**
     * Resume o humor que a pessoa registrou na Home, só se foi HOJE — é o único "contexto"
     * extra que mandamos para a IA, pra resposta vir mais sintonizada com o momento da pessoa.
     * Nenhum outro dado (nome, histórico completo etc.) sai do aparelho.
     */
    private suspend fun recentMoodContext(): String? {
        val last = moodDao.getAll().firstOrNull() ?: return null

        val today = Calendar.getInstance()
        val entryDay = Calendar.getInstance().apply { timeInMillis = last.timestamp }
        val isToday = today.get(Calendar.YEAR) == entryDay.get(Calendar.YEAR) &&
            today.get(Calendar.DAY_OF_YEAR) == entryDay.get(Calendar.DAY_OF_YEAR)
        if (!isToday) return null

        val label = when (last.mood) {
            "otimo" -> "ótimo"
            "bem" -> "bem"
            "normal" -> "normal"
            "triste" -> "triste"
            else -> "muito mal"
        }
        return "Humor que a pessoa registrou hoje no app: $label."
    }

    // ------------------------------------------------------------------ servidor da IA

    /**
     * Endereço do servidor proxy (o computador que roda proxy/server.py). Só o endereço fica no
     * aparelho: a chave da API fica no servidor, nunca no app nem no APK.
     */
    private fun showAiServerDialog() {
        val ctx = requireContext()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val input = EditText(ctx).apply {
            setText(Prefs.proxyUrl(ctx))
            hint = "http://10.0.2.2:8000"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 1
            setPadding(pad, pad, pad, pad)
        }
        AlertDialog.Builder(ctx)
            .setTitle("Servidor da IA")
            .setMessage(
                "Endereço do servidor proxy. Deixe em branco para usar só o modo offline. " +
                    "No emulador use http://10.0.2.2:8000. Em celular de verdade, o endereço precisa ser " +
                    "HTTPS (por exemplo, um túnel para o seu computador), porque o app não aceita HTTP comum fora do emulador."
            )
            .setView(input)
            .setPositiveButton("Salvar") { _, _ ->
                val url = input.text.toString().trim()
                Prefs.setProxyUrl(ctx, url)
                if (!AiConfig.isConfigured(ctx) && aiMode) setAiMode(false)
                Toast.makeText(
                    ctx,
                    if (url.isBlank()) "Servidor removido." else "Servidor salvo.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------ alternar IA

    private fun tryEnableAi() {
        val ctx = requireContext()
        if (!AiClient.isOnline(ctx)) {
            Toast.makeText(ctx, "Sem internet: a IA precisa de conexão.", Toast.LENGTH_LONG).show()
            return
        }
        if (Prefs.aiConsent(ctx)) {
            setAiMode(true)
            return
        }
        AlertDialog.Builder(ctx)
            .setTitle("Usar IA online?")
            .setMessage(
                "Com a IA ligada, o que você escrever (e as últimas mensagens da conversa) é enviado " +
                    "a um servidor para gerar a resposta. Não escreva dados pessoais, como nome completo " +
                    "ou documentos. A IA não substitui um profissional. Em crise, ligue 188 (CVV). " +
                    "Você pode desligar quando quiser."
            )
            .setPositiveButton("Aceito") { _, _ ->
                Prefs.setAiConsent(ctx, true)
                setAiMode(true)
            }
            .setNegativeButton("Agora não", null)
            .show()
    }

    private fun setAiMode(on: Boolean) {
        aiMode = on
        Prefs.setAiEnabled(requireContext(), on)
        applyAiUi()
        Toast.makeText(
            requireContext(),
            if (on) "IA online ligada." else "IA online desligada.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun applyAiUi() {
        binding.tvAiStatus.visibility = if (aiMode) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ limpar

    private fun confirmClear() {
        AlertDialog.Builder(requireContext())
            .setTitle("Limpar conversa")
            .setMessage("Isso apaga todas as mensagens desta conversa. Não pode ser desfeito.")
            .setPositiveButton("Limpar") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch {
                    chatDao.deleteAll()
                    adapter.setAll(emptyList())
                    addMessage(
                        ChatMessage.ROLE_BOT,
                        "Olá! Sou o assistente do Inspire-se. Pode me contar como você está?"
                    )
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // Ao sair da aba Conversa, se a pessoa mandou pelo menos uma mensagem, registra a visita
    // no Histórico (duração = tempo entre abrir e sair da aba). Usa lifecycleScope (do
    // Fragment, não da view) porque a view já está sendo destruída neste ponto.
    private fun logSessionIfNeeded() {
        if (!sentAnyThisSession) return
        val seconds = ((System.currentTimeMillis() - sessionStart) / 1000).toInt().coerceAtLeast(0)
        val ctx = context ?: return
        lifecycleScope.launch {
            AppDatabase.getInstance(ctx).activityDao().insert(
                ActivityEntry(
                    type = ActivityEntry.TYPE_CHAT,
                    label = "Conversa com o bot",
                    timestamp = System.currentTimeMillis(),
                    durationSec = seconds
                )
            )
        }
    }

    override fun onDestroyView() {
        logSessionIfNeeded()
        super.onDestroyView()
        _binding = null
    }
}
