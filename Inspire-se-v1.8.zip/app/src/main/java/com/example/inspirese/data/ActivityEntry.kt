package com.example.inspirese.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Uma linha da linha do tempo mostrada no Histórico: um exercício de respiração
 * concluído, uma conversa com o bot ou uma dica aberta. Diferente de MoodEntry (que
 * guarda só o humor), esta tabela é o que alimenta a lista do Histórico; os humores
 * continuam alimentando só os cartões de resumo dos últimos 7 dias.
 */
@Entity(tableName = "activity_entries")
data class ActivityEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,          // TYPE_BREATHING | TYPE_CHAT | TYPE_TIP
    val label: String,         // texto já pronto pra mostrar ("Exercício de respiração")
    val timestamp: Long,       // System.currentTimeMillis()
    val durationSec: Int = 0   // 0 quando a atividade não tem duração (ex.: dica lida)
) {
    companion object {
        const val TYPE_BREATHING = "breathing"
        const val TYPE_CHAT = "chat"
        const val TYPE_TIP = "tip"
    }
}
