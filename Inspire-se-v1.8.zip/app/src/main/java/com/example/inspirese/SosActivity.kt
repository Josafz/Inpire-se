package com.example.inspirese

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.inspirese.data.ActivityEntry
import com.example.inspirese.data.AppDatabase
import com.example.inspirese.databinding.ActivitySosBinding
import com.example.inspirese.sos.BreathCycle
import com.example.inspirese.sos.BreathPhase
import kotlinx.coroutines.launch

/**
 * Respiração guiada 4-7-8: inspire 4s, segure 7s (pulmões cheios), expire 8s, em loop.
 * Toda a matemática da animação está em BreathCycle (testada fora do Android); esta classe
 * só lê o relógio a cada 50ms e desenha o que BreathCycle devolve.
 *
 * Tela tem 3 estados visuais: parada (antes de "Começar"), em andamento e pausada — os dois
 * últimos compartilham o mesmo grupo de views (fl_ring, ll_dots, tv_message, btn_pause).
 */
class SosActivity : AppCompatActivity() {

    private enum class State { IDLE, RUNNING, PAUSED }

    private lateinit var binding: ActivitySosBinding
    private val handler = Handler(Looper.getMainLooper())
    private var state = State.IDLE
    private var wasRunningBeforeActivityPause = false

    // Tempo ativo de respiração (soma dos trechos em que esteve RUNNING, sem contar pausas).
    private var activeElapsedMs = 0L
    private var segmentStart = 0L
    private var lastCycle = -1

    private var mediaPlayer: MediaPlayer? = null
    private var soundOn = true

    private val messages = listOf(
        "Solte os ombros.",
        "Sinta os pés firmes no chão.",
        "Você está seguro agora.",
        "Isso vai passar.",
        "Deixe o maxilar relaxar.",
        "Você está indo bem. Continue respirando no seu ritmo."
    )

    private val tick = object : Runnable {
        override fun run() {
            val elapsed = activeElapsedMs + (System.currentTimeMillis() - segmentStart)
            val bstate = BreathCycle.stateAt(elapsed)

            binding.tvPhase.text = BreathCycle.phaseLabel(bstate.phase)
            binding.tvCount.text = bstate.remainingSeconds.toString()
            updateRing(bstate.phase, bstate.remainingSeconds)
            updateDots(bstate.cycle)

            if (bstate.cycle != lastCycle && bstate.cycle > 0) {
                binding.tvMessage.text = messages[(bstate.cycle - 1) % messages.size]
                lastCycle = bstate.cycle
            }

            handler.postDelayed(this, 50)
        }
    }

    private fun updateRing(phase: BreathPhase, remainingSeconds: Long) {
        val totalSec = when (phase) {
            BreathPhase.INSPIRE -> BreathCycle.IN_MS / 1000
            BreathPhase.SEGURE -> BreathCycle.HOLD_MS / 1000
            BreathPhase.EXPIRE -> BreathCycle.EXHALE_MS / 1000
        }
        val done = (totalSec - remainingSeconds).coerceIn(0, totalSec)
        val percent = ((done * 100) / totalSec).toInt()
        ring.progress = percent
    }

    private val dotViews by lazy {
        listOf(binding.dot0, binding.dot1, binding.dot2, binding.dot3)
    }

    private fun updateDots(cycle: Int) {
        val active = cycle % dotViews.size
        dotViews.forEachIndexed { index, view ->
            view.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (index == active) getColor(R.color.primary) else getColor(R.color.line)
            )
        }
    }

    private lateinit var ring: com.google.android.material.progressindicator.CircularProgressIndicator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ring = binding.flRing.getChildAt(0) as com.google.android.material.progressindicator.CircularProgressIndicator

        binding.btnBack.setOnClickListener { finishAndLog() }
        binding.btnStart.setOnClickListener { startBreathing() }
        binding.btnPause.setOnClickListener { togglePause() }
        binding.btnSound.setOnClickListener { toggleSound() }
    }

    private fun startBreathing() {
        state = State.RUNNING
        activeElapsedMs = 0L
        segmentStart = System.currentTimeMillis()
        lastCycle = -1

        binding.flIdleOrb.visibility = View.GONE
        binding.tvIdleHeadline.visibility = View.GONE
        binding.tvIdleSubtitle.visibility = View.GONE
        binding.cardTechnique.visibility = View.GONE
        binding.btnStart.visibility = View.GONE

        binding.flRing.visibility = View.VISIBLE
        binding.llDots.visibility = View.VISIBLE
        binding.tvMessage.visibility = View.VISIBLE
        binding.btnPause.visibility = View.VISIBLE
        binding.tvMessage.text = "Acompanhe o círculo. Inspire, segure e solte bem devagar."

        handler.removeCallbacks(tick)
        handler.post(tick)
        if (soundOn) startSound()
    }

    private fun togglePause() {
        if (state == State.RUNNING) {
            activeElapsedMs += System.currentTimeMillis() - segmentStart
            state = State.PAUSED
            handler.removeCallbacks(tick)
            mediaPlayer?.pause()
            binding.btnPause.text = "Continuar"
        } else if (state == State.PAUSED) {
            state = State.RUNNING
            segmentStart = System.currentTimeMillis()
            handler.post(tick)
            if (soundOn) startSound()
            binding.btnPause.text = "Pausar"
        }
    }

    private fun finishAndLog() {
        val totalMs = when (state) {
            State.RUNNING -> activeElapsedMs + (System.currentTimeMillis() - segmentStart)
            State.PAUSED -> activeElapsedMs
            State.IDLE -> 0L
        }
        val seconds = (totalMs / 1000).toInt()
        if (seconds >= 5) {
            lifecycleScope.launch {
                AppDatabase.getInstance(this@SosActivity).activityDao().insert(
                    ActivityEntry(
                        type = ActivityEntry.TYPE_BREATHING,
                        label = "Exercício de respiração",
                        timestamp = System.currentTimeMillis(),
                        durationSec = seconds
                    )
                )
                finish()
            }
        } else {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (wasRunningBeforeActivityPause) {
            wasRunningBeforeActivityPause = false
            segmentStart = System.currentTimeMillis()
            handler.post(tick)
            if (soundOn) startSound()
        }
    }

    override fun onPause() {
        super.onPause()
        if (state == State.RUNNING) {
            activeElapsedMs += System.currentTimeMillis() - segmentStart
            wasRunningBeforeActivityPause = true
        }
        handler.removeCallbacks(tick)
        mediaPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Voltar pelo gesto/botão do sistema também registra a duração, igual ao btn_back.
        finishAndLog()
    }

    private fun toggleSound() {
        soundOn = !soundOn
        binding.btnSound.text = if (soundOn) "🔊 Som ligado" else "🔇 Som desligado"
        if (soundOn) startSound() else mediaPlayer?.pause()
    }

    private fun startSound() {
        try {
            if (mediaPlayer == null) {
                // Procura app/src/main/res/raw/calm_loop.mp3. Se não existir,
                // resId fica 0 e o app segue normalmente, sem som.
                val resId = resources.getIdentifier("calm_loop", "raw", packageName)
                if (resId != 0) {
                    mediaPlayer = MediaPlayer.create(this, resId)
                    mediaPlayer?.isLooping = true
                }
            }
            mediaPlayer?.start()
        } catch (e: Exception) {
            // Sem áudio disponível: o app continua funcionando normalmente
        }
    }
}
