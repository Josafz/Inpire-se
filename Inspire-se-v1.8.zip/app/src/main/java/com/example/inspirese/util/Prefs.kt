package com.example.inspirese.util

import android.content.Context

/**
 * Configurações simples (pouco dado, formato chave/valor) via SharedPreferences.
 * Dado que cresce e precisa de consulta (humor, conversa) fica no Room; aqui só ajustes.
 */
object Prefs {
    private const val FILE = "inspirese_prefs"

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- chat ----
    fun aiConsent(ctx: Context): Boolean = sp(ctx).getBoolean("ai_consent", false)
    fun setAiConsent(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("ai_consent", v).apply()

    fun aiEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("ai_enabled", false)
    fun setAiEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("ai_enabled", v).apply()

    fun apiKey(ctx: Context): String = sp(ctx).getString("api_key", "") ?: ""
    fun setApiKey(ctx: Context, key: String) = sp(ctx).edit().putString("api_key", key.trim()).apply()

    fun proxyUrl(ctx: Context): String = sp(ctx).getString("proxy_url", "") ?: ""
    fun setProxyUrl(ctx: Context, url: String) = sp(ctx).edit().putString("proxy_url", url.trim()).apply()

    // ---- lembrete diário ----
    fun reminderEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("reminder_enabled", false)
    fun setReminderEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("reminder_enabled", v).apply()

    fun reminderHour(ctx: Context): Int = sp(ctx).getInt("reminder_hour", 20)
    fun reminderMinute(ctx: Context): Int = sp(ctx).getInt("reminder_minute", 0)
    fun setReminderTime(ctx: Context, hour: Int, minute: Int) =
        sp(ctx).edit().putInt("reminder_hour", hour).putInt("reminder_minute", minute).apply()
}
