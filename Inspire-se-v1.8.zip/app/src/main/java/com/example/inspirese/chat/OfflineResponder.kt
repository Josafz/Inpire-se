package com.example.inspirese.chat

/**
 * Resposta automática do chat quando a IA não está ligada (é o modo padrão, 100% offline).
 * NÃO é inteligência artificial — é um conjunto fixo de respostas, escolhidas por palavras-chave
 * no texto da pessoa. O CrisisDetector roda ANTES desta classe (em ChatFragment): texto de
 * crise nunca chega aqui, tem resposta própria com CVV/SAMU.
 */
object OfflineResponder {

    private val panic = listOf("panico", "pânico", "desesper", "sufoc", "taquicard")
    private val anxious = listOf("ansio", "nervos", "preocup", "aflit", "tenso", "tensa", "agitad")
    private val sad = Regex("trist|chorar|sozinh|desanim|cansad")
    private val breathing = listOf("respir")
    private val good = Regex("\\bbem\\b|\\bbom\\b|\\bboa\\b|otimo|ótimo|feliz|melhor|tranquil")

    // Âncora no início E no fim: só bate se a frase inteira for essencialmente uma saudação
    // ("Bom dia, tudo bem?"), pra "bom"/"bem" de cumprimento não virar "humor positivo" por engano.
    private val pureGreeting = Regex(
        "^(oi|ola|e ai|bom dia|boa tarde|boa noite)[,!. ]*" +
            "(tudo bem|como vai|como voce esta)?[?!. ]*$"
    )

    fun reply(text: String): String {
        val n = CrisisDetector.normalize(text)
        return when {
            panic.any { n.contains(it) } ->
                "Isso parece pesado agora. Vamos respirar juntos? Toca no SOS aqui embaixo — " +
                    "a respiração guiada ajuda a acalmar o corpo em poucos minutos."
            anxious.any { n.contains(it) } ->
                "Sinto muito que você esteja assim. Me conta um pouco mais sobre o que está " +
                    "deixando você ansioso(a)? Se quiser, o botão SOS tem uma respiração guiada."
            sad.containsMatchIn(n) ->
                "Entendo. Dias assim acontecem, e está tudo bem sentir isso. Estou aqui — " +
                    "quer falar sobre o que aconteceu?"
            pureGreeting.matches(n) ->
                "Oi! Fico feliz em conversar com você. Como você está se sentindo hoje?"
            breathing.any { n.contains(it) } ->
                "Boa ideia. Toca no botão SOS aqui embaixo: ele guia você pela técnica 4-7-8, " +
                    "inspire 4s, segure 7s, expire 8s."
            good.containsMatchIn(n) ->
                "Que bom ouvir isso! Guarda esse momento com você. Tem mais alguma coisa que " +
                    "você queira conversar?"
            else ->
                "Estou te ouvindo. Me conta um pouco mais sobre como você está hoje."
        }
    }
}
