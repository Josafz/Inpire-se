package com.example.inspirese.chat

import android.content.Context
import com.example.inspirese.util.Prefs

/**
 * Configuração da IA do Inspire-se.
 * Suporta servidor Proxy intermediário e/ou chave direta de API (como Google Gemini ou OpenAI).
 *
 * Pode ser configurado aqui no código ou dinamicamente pelo próprio usuário nas opções do Chat.
 */
object AiConfig {
    /** Servidor proxy (ex.: "http://10.0.2.2:8000"). */
    const val DEFAULT_PROXY_URL = ""

    /** Chave da API (ex.: Gemini "AIzaSy..." ou OpenAI "sk-..."). */
    const val DEFAULT_GEMINI_API_KEY = ""

    fun getApiKey(ctx: Context): String {
        val custom = Prefs.apiKey(ctx)
        return if (custom.isNotBlank()) custom.trim() else DEFAULT_GEMINI_API_KEY.trim()
    }

    fun getProxyUrl(ctx: Context): String {
        val custom = Prefs.proxyUrl(ctx)
        return if (custom.isNotBlank()) custom.trim() else DEFAULT_PROXY_URL.trim()
    }

    fun isConfigured(ctx: Context): Boolean {
        return getApiKey(ctx).isNotBlank() || getProxyUrl(ctx).isNotBlank()
    }
}
