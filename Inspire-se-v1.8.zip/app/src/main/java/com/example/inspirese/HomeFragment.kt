package com.example.inspirese

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.inspirese.data.AppDatabase
import com.example.inspirese.data.MoodEntry
import com.example.inspirese.databinding.FragmentHomeBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.tvGreeting.text = greeting()

        binding.moodOtimo.setOnClickListener { registrar("otimo", "😄 Ótimo") }
        binding.moodBem.setOnClickListener { registrar("bem", "🙂 Bem") }
        binding.moodNormal.setOnClickListener { registrar("normal", "😐 Normal") }
        binding.moodTriste.setOnClickListener { registrar("triste", "😕 Triste") }
        binding.moodMuitoMal.setOnClickListener { registrar("muito_mal", "😢 Muito mal") }
    }

    private fun greeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when {
            hour < 12 -> "Bom dia! ☀️"
            hour < 18 -> "Boa tarde! 🌤️"
            else -> "Boa noite! 🌙"
        }
    }

    private fun registrar(mood: String, label: String) {
        val dao = AppDatabase.getInstance(requireContext()).moodDao()
        val now = System.currentTimeMillis()

        lifecycleScope.launch {
            dao.insert(MoodEntry(mood = mood, timestamp = now))

            val fmt = SimpleDateFormat("HH:mm", Locale("pt", "BR"))
            binding.tvNote.visibility = View.VISIBLE
            binding.tvNote.text = "Registrado: $label, hoje às ${fmt.format(Date(now))}."
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
