package com.example.inspirese.data

/**
 * Uma dica de autocuidado. Conteúdo fixo (não vem do banco) — é texto escrito por nós,
 * só organizado aqui para alimentar a lista da aba Dicas e a tela de detalhe.
 */
data class Tip(
    val id: String,
    val emoji: String,
    val title: String,
    val category: String,     // Tip.CAT_MENTAL ou Tip.CAT_BEM_ESTAR
    val summary: String,      // linha curta, mostrada na lista
    val body: String,         // parágrafo de abertura da tela de detalhe
    val steps: List<String>   // passos numerados da tela de detalhe
) {
    companion object {
        const val CAT_MENTAL = "mental"
        const val CAT_BEM_ESTAR = "bem_estar"
    }
}

object Tips {

    val all: List<Tip> = listOf(
        Tip(
            id = "ansiedade",
            emoji = "🧠",
            title = "Como lidar com a ansiedade",
            category = Tip.CAT_MENTAL,
            summary = "Dicas práticas para acalmar a mente e o corpo.",
            body = "A ansiedade é uma resposta natural do nosso corpo, mas quando aparece com " +
                "muita frequência, pode pesar na qualidade de vida. Estas quatro mudanças " +
                "simples, feitas aos poucos, ajudam a reduzir os picos de ansiedade com o tempo.",
            steps = listOf(
                "Respire fundo: técnicas de respiração ajudam a reduzir os sintomas na hora.",
                "Mantenha uma rotina: horários regulares de sono e alimentação fazem diferença.",
                "Evite excesso de telas, principalmente perto de dormir.",
                "Pratique atividades que você gosta, mesmo que por pouco tempo."
            )
        ),
        Tip(
            id = "atencao_plena",
            emoji = "👀",
            title = "Olhe ao redor: 5-4-3-2-1",
            category = Tip.CAT_MENTAL,
            summary = "Um exercício rápido de atenção plena para o aqui e agora.",
            body = "Quando a mente acelera, trazer a atenção para os sentidos ajuda o corpo a " +
                "sair do modo de alerta. Esta técnica usa os cinco sentidos, um por vez.",
            steps = listOf(
                "Diga 5 coisas que você vê ao seu redor, com calma.",
                "Diga 4 coisas que você pode tocar agora.",
                "Diga 3 coisas que você escuta neste momento.",
                "Diga 2 coisas que você cheira e 1 que sente o gosto."
            )
        ),
        Tip(
            id = "falar",
            emoji = "📞",
            title = "Fale com alguém",
            category = Tip.CAT_MENTAL,
            summary = "Companhia ajuda mais do que parece nos dias difíceis.",
            body = "Dividir o que você sente com alguém de confiança costuma aliviar o peso do " +
                "momento, mesmo quando essa pessoa não tem uma solução para oferecer.",
            steps = listOf(
                "Pense em alguém com quem você se sinta à vontade.",
                "Ligue ou mande uma mensagem, só para ter companhia.",
                "Se não tiver vontade de falar sobre o que sente, está tudo bem — só conversar já ajuda.",
                "Sem ninguém disponível agora, o CVV (188) atende 24 horas, de graça."
            )
        ),
        Tip(
            id = "banho",
            emoji = "🛁",
            title = "Banho morno",
            category = Tip.CAT_BEM_ESTAR,
            summary = "O calor da água ajuda o corpo a soltar a tensão.",
            body = "Um banho morno, sem pressa, relaxa os músculos e reduz a tensão acumulada " +
                "no corpo. Evite água muito quente, que deixa a pele seca e pode irritar.",
            steps = listOf(
                "Separe de 10 a 15 minutos sem pressa.",
                "Use água morna, nunca muito quente.",
                "Respire devagar enquanto a água cai sobre os ombros.",
                "Depois, vista algo confortável e evite telas por uns minutos."
            )
        ),
        Tip(
            id = "caminhada",
            emoji = "🚶",
            title = "Caminhada leve",
            category = Tip.CAT_BEM_ESTAR,
            summary = "Movimento leve, de preferência ao ar livre.",
            body = "Caminhar em ritmo confortável solta o corpo e ajuda a organizar os " +
                "pensamentos. Não precisa de pressa nem de distância — o importante é se mexer.",
            steps = listOf(
                "Escolha um trajeto tranquilo, de preferência ao ar livre.",
                "Caminhe por cerca de 15 minutos, em ritmo confortável.",
                "Preste atenção na respiração e no que vê ao redor.",
                "Sem condições de sair, vale caminhar devagar dentro de casa."
            )
        ),
        Tip(
            id = "alongamento",
            emoji = "🧘",
            title = "Alongamento suave",
            category = Tip.CAT_BEM_ESTAR,
            summary = "Soltar o corpo, sentado mesmo, sem forçar.",
            body = "Tensão no corpo costuma acompanhar a ansiedade. Um alongamento leve, sem " +
                "forçar, ajuda a soltar os ombros e o pescoço em poucos minutos.",
            steps = listOf(
                "Sente-se numa cadeira com os pés apoiados no chão.",
                "Gire os ombros devagar, para frente e para trás.",
                "Incline a cabeça com cuidado para cada lado, sem forçar.",
                "Pare se sentir dor — o objetivo é relaxar, não desafiar o corpo."
            )
        ),
        Tip(
            id = "bebida",
            emoji = "🍵",
            title = "Uma bebida morna",
            category = Tip.CAT_BEM_ESTAR,
            summary = "Um chá sem cafeína, bebido com calma.",
            body = "O ritual de preparar e beber algo morno, aos poucos, dá ao corpo um sinal " +
                "de pausa. Cafeína em excesso pode piorar a sensação de ansiedade.",
            steps = listOf(
                "Prepare um chá sem cafeína ou um copo de água.",
                "Beba aos poucos, sem pressa.",
                "Evite café e refrigerante em excesso, principalmente à noite.",
                "Aproveite o momento só para isso, sem olhar o celular."
            )
        ),
        Tip(
            id = "movimento",
            emoji = "🏊",
            title = "Movimento que você gosta",
            category = Tip.CAT_BEM_ESTAR,
            summary = "Hidroginástica, dança ou tai chi — o que der prazer.",
            body = "Atividade física regular, feita com prazer e não por obrigação, é uma das " +
                "formas mais estudadas de reduzir a ansiedade ao longo do tempo.",
            steps = listOf(
                "Escolha uma atividade que você realmente gosta de fazer.",
                "Comece com 2 a 3 vezes por semana, sem exagerar.",
                "Vá no seu ritmo — não precisa comparar com ninguém.",
                "Comemore o hábito, não só o resultado."
            )
        )
    )

    fun byId(id: String?): Tip? = if (id == null) null else all.firstOrNull { it.id == id }
}
