package com.example.inspirese.chat

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.inspirese.data.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente de IA do Inspire-se.
 * Conecta com a API do Google Gemini, OpenAI ou servidor Proxy intermediário.
 * Usa apenas chamadas nativas do Android (HttpURLConnection + org.json).
 */
object AiClient {

    class AiException(message: String) : Exception(message)

    const val SYSTEM_PROMPT =
        "Você é um assistente de acolhimento e suporte emocional para o aplicativo Inspire-se, altamente capacitado em princípios de psicologia (como Terapia Cognitivo-Comportamental - TCC, Aceitação e Compromisso - ACT, e Mindfulness).\n\n" +
            "DIRETRIZES DE PERSONALIDADE E ESTILO:\n" +
            "1. TOM HUMANO E CRIATIVO: Seja extremamente empático, acolhedor, humano e sensível. Evite respostas genéricas, clichês ou automatizadas. Reaja profundamente ao que a pessoa disse.\n" +
            "2. ABORDAGEM PSICOLÓGICA: Utilize técnicas reflexivas e psicológicas leves:\n" +
            "   - Validação Emocional: Primeiro, acolha e normalize a emoção do usuário sem julgar.\n" +
            "   - Reestruturação e Defusão Cognitiva: Ajude a pessoa a notar pensamentos automáticos ou catastróficos com suavidade.\n" +
            "   - Metáforas Criativas: Use metáforas visuais e inspiradoras para explicar a ansiedade (ex: 'pensamentos são como ondas no mar', 'a mente às vezes antecipa tempestades em dias de sol').\n" +
            "   - Perguntas Reflexivas: Faça 1 pergunta aberta e criativa por resposta que ajude a pessoa a se conectar com o corpo ou a investigar a origem do sentimento (ex: 'Se essa ansiedade tivesse um formato ou uma cor agora, como ela seria?').\n" +
            "3. TÉCNICAS PRÁTICAS: Quando oportuno, proponha exercícios curtos de grounding/ancoragem no presente (técnica dos 5 sentidos, pausas de respiração) e mencione que o app possui a aba SOS (respiração guiada 4-7-8) e a aba Dicas.\n" +
            "4. CONCISÃO: Escreva em português do Brasil, com linguagem simples e acolhedora, mantendo a resposta em no máximo 4 frases ou parágrafos curtos (fáceis de ler na tela do celular).\n" +
            "5. LIMITES ÉTICOS E SEGURANÇA: Seja ético. Não afirme ser psicólogo ou médico nem faça diagnósticos. Se o usuário indicar crise severa ou ideação suicida, acolha com carinho e forneça imediatamente o CVV (ligue 188, 24h gratuito) e SAMU (192)."

    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun reply(
        context: Context,
        history: List<ChatMessage>,
        moodContext: String? = null
    ): String = withContext(Dispatchers.IO) {
        val proxyUrl = AiConfig.getProxyUrl(context)
        val apiKey = AiConfig.getApiKey(context)

        when {
            proxyUrl.isNotBlank() -> callProxy(proxyUrl, history, moodContext)
            apiKey.isNotBlank() -> {
                if (apiKey.startsWith("sk-")) {
                    callOpenAi(apiKey, history, moodContext)
                } else {
                    callGemini(apiKey, history, moodContext)
                }
            }
            else -> throw AiException("IA não configurada. Insira uma chave da API do Gemini/OpenAI ou a URL do Proxy.")
        }
    }

    private fun callGemini(apiKey: String, history: List<ChatMessage>, moodContext: String?): String {
        val fullSystemPrompt = if (!moodContext.isNullOrBlank()) {
            "$SYSTEM_PROMPT\n\nContexto sobre o usuário agora: $moodContext"
        } else {
            SYSTEM_PROMPT
        }

        val contents = JSONArray()
        history.takeLast(12).forEach { m ->
            val role = if (m.role == ChatMessage.ROLE_USER) "user" else "model"
            contents.put(
                JSONObject().put("role", role).put(
                    "parts", JSONArray().put(JSONObject().put("text", m.text))
                )
            )
        }

        val generationConfig = JSONObject().apply {
            put("temperature", 0.75)
            put("topP", 0.95)
            put("maxOutputTokens", 500)
        }

        val payload = JSONObject().apply {
            put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", fullSystemPrompt))))
            put("contents", contents)
            put("generationConfig", generationConfig)
        }

        val urlStr = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val errorMsg = conn.errorStream?.bufferedReader()?.use { it.readText() }
                throw AiException("Erro $code na API do Gemini: $errorMsg")
            }

            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(text)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val replyText = parts.getJSONObject(0).optString("text", "").trim()
                    if (replyText.isNotEmpty()) return replyText
                }
            }
            throw AiException("Resposta vazia da IA")
        } catch (e: AiException) {
            throw e
        } catch (e: IOException) {
            throw AiException("Falha na conexão com a API da IA: ${e.message}")
        } catch (e: JSONException) {
            throw AiException("Erro ao processar resposta da IA")
        } finally {
            conn.disconnect()
        }
    }

    private fun callOpenAi(apiKey: String, history: List<ChatMessage>, moodContext: String?): String {
        val fullSystemPrompt = if (!moodContext.isNullOrBlank()) {
            "$SYSTEM_PROMPT\n\nContexto sobre o usuário agora: $moodContext"
        } else {
            SYSTEM_PROMPT
        }

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", fullSystemPrompt))

        history.takeLast(12).forEach { m ->
            val role = if (m.role == ChatMessage.ROLE_USER) "user" else "assistant"
            messages.put(JSONObject().put("role", role).put("content", m.text))
        }

        val payload = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("temperature", 0.75)
            put("max_tokens", 500)
            put("messages", messages)
        }

        val conn = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) {
                throw AiException("Erro $code da API OpenAI")
            }

            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val choices = JSONObject(text).optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val msg = choices.getJSONObject(0).optJSONObject("message")
                val replyText = msg?.optString("content", "")?.trim()
                if (!replyText.isNullOrEmpty()) return replyText
            }
            throw AiException("Resposta vazia da IA")
        } catch (e: AiException) {
            throw e
        } catch (e: IOException) {
            throw AiException("Falha na conexão com a API")
        } catch (e: JSONException) {
            throw AiException("Erro ao processar resposta da IA")
        } finally {
            conn.disconnect()
        }
    }

    private fun callProxy(proxyUrl: String, history: List<ChatMessage>, moodContext: String?): String {
        val messages = JSONArray()
        history.takeLast(12).forEach { m ->
            val role = if (m.role == ChatMessage.ROLE_USER) "user" else "assistant"
            messages.put(JSONObject().put("role", role).put("content", m.text))
        }
        val payload = JSONObject().put("messages", messages)
        if (!moodContext.isNullOrBlank()) payload.put("context", moodContext)

        val endpoint = if (proxyUrl.endsWith("/chat")) proxyUrl else "${proxyUrl.trimEnd('/')}/chat"
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) throw AiException("Servidor respondeu $code")

            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return JSONObject(text).getString("reply")
        } catch (e: AiException) {
            throw e
        } catch (e: IOException) {
            throw AiException("Sem conexão com o servidor proxy")
        } catch (e: JSONException) {
            throw AiException("Resposta inválida do servidor proxy")
        } finally {
            conn.disconnect()
        }
    }
}
