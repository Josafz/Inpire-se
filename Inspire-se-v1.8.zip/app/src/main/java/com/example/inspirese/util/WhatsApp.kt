package com.example.inspirese.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object WhatsApp {
    /**
     * Abre o WhatsApp com o número e a mensagem preenchidos.
     * O usuário revisa e confirma antes de enviar.
     */
    fun open(context: Context, phone: String, message: String) {
        val digitsOnly = phone.filter { it.isDigit() }
        val formattedPhone = if (digitsOnly.length in 10..11 && !phone.startsWith("+")) {
            "55$digitsOnly"
        } else {
            digitsOnly
        }

        val url = "https://api.whatsapp.com/send?phone=$formattedPhone&text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp não encontrado no aparelho", Toast.LENGTH_SHORT).show()
        }
    }
}
