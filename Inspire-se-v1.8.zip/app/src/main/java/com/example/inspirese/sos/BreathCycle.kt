package com.example.inspirese.sos

import kotlin.math.PI
import kotlin.math.cos

enum class BreathPhase { INSPIRE, SEGURE, EXPIRE }

/** O estado da respiração num instante: fase, segundos restantes NA fase, e a escala do círculo (0.6 a 1.0). */
data class BreathState(val phase: BreathPhase, val remainingSeconds: Long, val scale: Float, val cycle: Int)

/**
 * A técnica 4-7-8: inspire 4s, segure 7s (pulmões cheios, círculo parado no tamanho máximo),
 * expire 8s. Ciclo de 19s, repetido.
 *
 * Lógica pura (sem Android), então dá para testar fora do aparelho — é isso que faz a
 * animação da SosActivity ser só "ler o relógio e desenhar o que ele manda".
 */
object BreathCycle {
    const val IN_MS = 4000L
    const val HOLD_MS = 7000L
    const val EXHALE_MS = 8000L
    const val CYCLE_MS = IN_MS + HOLD_MS + EXHALE_MS   // 19000
    const val MIN_SCALE = 0.6f

    fun ease(x: Float): Float = (0.5 - cos(PI * x) / 2).toFloat()

    fun stateAt(elapsedMs: Long): BreathState {
        val cycle = (elapsedMs / CYCLE_MS).toInt()
        val t = elapsedMs % CYCLE_MS

        return when {
            t < IN_MS -> {
                val remain = IN_MS / 1000 - t / 1000
                val scale = MIN_SCALE + (1 - MIN_SCALE) * ease(t.toFloat() / IN_MS)
                BreathState(BreathPhase.INSPIRE, remain, scale, cycle)
            }
            t < IN_MS + HOLD_MS -> {
                val tt = t - IN_MS
                val remain = HOLD_MS / 1000 - tt / 1000
                BreathState(BreathPhase.SEGURE, remain, 1f, cycle)
            }
            else -> {
                val tt = t - IN_MS - HOLD_MS
                val remain = EXHALE_MS / 1000 - tt / 1000
                val scale = 1f - (1 - MIN_SCALE) * ease(tt.toFloat() / EXHALE_MS)
                BreathState(BreathPhase.EXPIRE, remain, scale, cycle)
            }
        }
    }

    fun phaseLabel(phase: BreathPhase): String = when (phase) {
        BreathPhase.INSPIRE -> "Inspire"
        BreathPhase.SEGURE -> "Segure"
        BreathPhase.EXPIRE -> "Expire"
    }
}
