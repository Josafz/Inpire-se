package com.example.inspirese

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.inspirese.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        /** A notificação do lembrete manda este extra para abrir direto a respiração guiada. */
        const val EXTRA_OPEN_SOS = "open_sos"
    }

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, HomeFragment())
                .commit()

            // Veio do toque na notificação do lembrete: já abre a respiração
            if (intent.getBooleanExtra(EXTRA_OPEN_SOS, false)) {
                startActivity(Intent(this, SosActivity::class.java))
            }
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            // O SOS é uma tela cheia (Activity), não uma aba de conteúdo: abre por cima e
            // devolve "false" para o menu continuar marcando a aba que já estava selecionada.
            if (item.itemId == R.id.nav_sos) {
                startActivity(Intent(this, SosActivity::class.java))
                return@setOnItemSelectedListener false
            }
            val fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_chat -> ChatFragment()
                R.id.nav_tips -> TipsFragment()
                R.id.nav_history -> HistoryFragment()
                else -> HomeFragment()
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit()
            true
        }
    }

    /** Troca de aba por código (hoje: o botão ← da Conversa volta para a Home). */
    fun selectTab(itemId: Int) {
        binding.bottomNav.selectedItemId = itemId
    }
}
