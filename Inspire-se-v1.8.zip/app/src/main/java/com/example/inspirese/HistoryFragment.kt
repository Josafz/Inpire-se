package com.example.inspirese

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.inspirese.adapter.HistoryAdapter
import com.example.inspirese.adapter.HistoryRow
import com.example.inspirese.data.ActivityEntry
import com.example.inspirese.data.AppDatabase
import com.example.inspirese.databinding.FragmentHistoryBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val adapter = HistoryAdapter { showDetail(it) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvHistory.layoutManager = LinearLayoutManager(requireContext())
        binding.rvHistory.adapter = adapter
        binding.btnClear.setOnClickListener { confirmClear() }
        loadHistory()
    }

    override fun onResume() {
        super.onResume()
        loadHistory()
    }

    private fun loadHistory() {
        val db = AppDatabase.getInstance(requireContext())
        lifecycleScope.launch {
            val moods = db.moodDao().getAll()
            val activities = db.activityDao().getAll()   // já vem ordenado por timestamp DESC
            val rows = groupByDate(activities)

            adapter.submitList(rows)
            binding.tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            binding.rvHistory.visibility = if (rows.isEmpty()) View.GONE else View.VISIBLE

            val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
            val last7 = moods.filter { it.timestamp >= since }
            binding.tvCountOtimo.text = "😄\n${last7.count { it.mood == "otimo" }}"
            binding.tvCountBem.text = "🙂\n${last7.count { it.mood == "bem" }}"
            binding.tvCountNormal.text = "😐\n${last7.count { it.mood == "normal" }}"
            binding.tvCountTriste.text = "😕\n${last7.count { it.mood == "triste" }}"
            binding.tvCountMuitoMal.text = "😢\n${last7.count { it.mood == "muito_mal" }}"
        }
    }

    // Agrupa as atividades (já ordenadas da mais nova pra mais antiga) em cabeçalhos de data
    // ("Hoje, 10 de junho de 2026" / "Ontem, ..." / data completa) seguidos das linhas do dia.
    private fun groupByDate(activities: List<ActivityEntry>): List<HistoryRow> {
        if (activities.isEmpty()) return emptyList()

        val dayFmt = SimpleDateFormat("d 'de' MMMM 'de' yyyy", Locale("pt", "BR"))
        val today = dayKey(Calendar.getInstance())
        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yesterday = dayKey(yesterdayCal)

        val rows = mutableListOf<HistoryRow>()
        var lastKey: String? = null
        for (activity in activities) {
            val cal = Calendar.getInstance().apply { timeInMillis = activity.timestamp }
            val key = dayKey(cal)
            if (key != lastKey) {
                val fullDate = dayFmt.format(Date(activity.timestamp))
                val label = when (key) {
                    today -> "Hoje, $fullDate"
                    yesterday -> "Ontem, $fullDate"
                    else -> fullDate
                }
                rows.add(HistoryRow.Header(label))
                lastKey = key
            }
            rows.add(HistoryRow.Entry(activity))
        }
        return rows
    }

    private fun dayKey(cal: Calendar): String = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"

    private fun showDetail(item: ActivityEntry) {
        val fmt = SimpleDateFormat("EEEE, d 'de' MMMM 'às' HH:mm", Locale("pt", "BR"))
        val when_ = fmt.format(Date(item.timestamp))
        val duration = if (item.durationSec > 0) {
            "\n\nDuração: ${TimeUnit.SECONDS.toMinutes(item.durationSec.toLong())} min"
        } else ""
        AlertDialog.Builder(requireContext())
            .setTitle(item.label)
            .setMessage("$when_$duration")
            .setPositiveButton("Fechar", null)
            .show()
    }

    private fun confirmClear() {
        val db = AppDatabase.getInstance(requireContext())
        AlertDialog.Builder(requireContext())
            .setTitle("Apagar histórico")
            .setMessage("Isso vai apagar todos os registros de humor e de atividades. Não pode ser desfeito.")
            .setPositiveButton("Apagar") { _, _ ->
                lifecycleScope.launch {
                    db.moodDao().deleteAll()
                    db.activityDao().deleteAll()
                    loadHistory()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
