import com.example.inspirese.chat.OfflineResponder

var fails = 0
fun check(name: String, ok: Boolean) {
    println((if (ok) "OK   " else "FALHOU ") + name)
    if (!ok) fails++
}

fun main() {
    // pânico tem prioridade sobre ansiedade (frases que batem com as duas listas)
    check("'em pânico' -> resposta de pânico",
        OfflineResponder.reply("estou em pânico agora").contains("respirar juntos"))
    check("'desesperado' -> resposta de pânico",
        OfflineResponder.reply("Estou desesperada, não sei o que fazer").contains("respirar juntos"))

    check("'ansioso' -> resposta de ansiedade",
        OfflineResponder.reply("Hoje estou muito ansioso").contains("Me conta um pouco mais"))
    check("'nervosa' -> resposta de ansiedade",
        OfflineResponder.reply("to nervosa com a prova").contains("Me conta um pouco mais"))

    check("'triste' -> resposta de tristeza",
        OfflineResponder.reply("Estou muito triste hoje").contains("Dias assim acontecem"))
    check("'sozinho' -> resposta de tristeza",
        OfflineResponder.reply("me sinto muito sozinho").contains("Dias assim acontecem"))

    check("'respirar' -> sugere o SOS",
        OfflineResponder.reply("quero aprender a respirar melhor").contains("4-7-8"))

    check("'bem' -> resposta positiva",
        OfflineResponder.reply("Hoje eu estou bem").contains("Que bom ouvir"))
    check("'feliz' -> resposta positiva",
        OfflineResponder.reply("estou muito feliz com o resultado").contains("Que bom ouvir"))

    check("frase sem palavra-chave -> resposta genérica",
        OfflineResponder.reply("Vou contar uma coisa que aconteceu no trabalho")
            .contains("Me conta um pouco mais sobre como você está hoje"))

    check("maiúsculas/acento não atrapalham (ANSIOSA)",
        OfflineResponder.reply("ESTOU ANSIOSA").contains("Me conta um pouco mais"))

    // "bom dia"/"boa tarde" não devem disparar a resposta positiva por engano
    check("'bom dia' sozinho não é tratado como humor positivo",
        !OfflineResponder.reply("Bom dia, tudo bem?").contains("Que bom ouvir"))

    println(if (fails == 0) "\nTODOS OS TESTES PASSARAM" else "\n$fails TESTE(S) FALHARAM")
    if (fails > 0) kotlin.system.exitProcess(1)
}
