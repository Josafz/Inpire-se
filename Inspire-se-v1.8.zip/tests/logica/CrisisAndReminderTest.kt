import com.example.inspirese.chat.CrisisDetector
import com.example.inspirese.reminder.ReminderTime
import java.time.ZoneId
import java.time.ZonedDateTime

var fails = 0
fun check(name: String, ok: Boolean) {
    println((if (ok) "OK   " else "FALHOU ") + name)
    if (!ok) fails++
}

fun main() {
    // ---- detector de crise ----
    val crise = listOf("Quero morrer", "não aguento mais", "SUICÍDIO", "vou me matar", "quero   sumir", "Penso em me machucar", "acabar com a minha vida")
    val normal = listOf("estou bem", "hoje foi um dia difícil no trabalho", "quero tomar um chá", "não consigo dormir", "estou ansioso")
    crise.forEach { check("detecta crise: \"$it\"", CrisisDetector.isCrisis(it)) }
    normal.forEach { check("não dispara em: \"$it\"", !CrisisDetector.isCrisis(it)) }
    check("normalize tira acento", CrisisDetector.normalize("  AÇÃO  Ruim ") == "acao ruim")

    // ---- horário do lembrete ----
    val z = ZoneId.of("America/Sao_Paulo")
    fun at(h: Int, m: Int, s: Int = 0) = ZonedDateTime.of(2026, 9, 28, h, m, s, 0, z)
    val hour = 3_600_000L
    check("19:00 -> 20:00 = 1h", ReminderTime.initialDelayMillis(at(19, 0), 20, 0) == hour)
    check("21:00 -> 20:00 = 23h", ReminderTime.initialDelayMillis(at(21, 0), 20, 0) == 23 * hour)
    check("20:00:00 exato -> amanhã = 24h", ReminderTime.initialDelayMillis(at(20, 0), 20, 0) == 24 * hour)
    check("19:59:30 -> 20:00 = 30s", ReminderTime.initialDelayMillis(at(19, 59, 30), 20, 0) == 30_000L)
    check("00:05 -> 08:30 = 8h25", ReminderTime.initialDelayMillis(at(0, 5), 8, 30) == 8 * hour + 25 * 60_000L)

    println(if (fails == 0) "\nTODOS OS TESTES PASSARAM" else "\n$fails TESTE(S) FALHARAM")
    if (fails > 0) kotlin.system.exitProcess(1)
}
