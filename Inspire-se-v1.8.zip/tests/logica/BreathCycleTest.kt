import com.example.inspirese.sos.BreathCycle
import com.example.inspirese.sos.BreathPhase

var fails = 0
fun check(name: String, ok: Boolean) {
    println((if (ok) "OK   " else "FALHOU ") + name)
    if (!ok) fails++
}

fun main() {
    // --- fases e durações ---
    check("IN=4s HOLD=7s EXHALE=8s CYCLE=19s", BreathCycle.IN_MS == 4000L && BreathCycle.HOLD_MS == 7000L && BreathCycle.EXHALE_MS == 8000L && BreathCycle.CYCLE_MS == 19000L)

    // --- contagem regressiva do Inspire: 4,3,2,1 (não 5,4,3,2,1) ---
    val inSeq = (0..3).map { BreathCycle.stateAt(it * 1000L).remainingSeconds }
    check("Inspire conta 4,3,2,1 nos 4 segundos $inSeq", inSeq == listOf(4L, 3L, 2L, 1L))
    check("t=3999ms ainda é Inspire, remain=1", BreathCycle.stateAt(3999).let { it.phase == BreathPhase.INSPIRE && it.remainingSeconds == 1L })

    // --- transição pro Segure em t=4000 ---
    val holdStart = BreathCycle.stateAt(4000)
    check("t=4000 já é Segure", holdStart.phase == BreathPhase.SEGURE)
    check("Segure começa em 7", holdStart.remainingSeconds == 7L)
    check("escala é 1.0 (cheio) o Segure inteiro", (0..6).all { BreathCycle.stateAt(4000L + it * 1000).scale == 1f })
    check("t=10999ms ainda é Segure, remain=1", BreathCycle.stateAt(10999).let { it.phase == BreathPhase.SEGURE && it.remainingSeconds == 1L })

    // --- transição pro Expire em t=11000 (4000+7000) ---
    val exhaleStart = BreathCycle.stateAt(11000)
    check("t=11000 já é Expire", exhaleStart.phase == BreathPhase.EXPIRE)
    check("Expire começa em 8", exhaleStart.remainingSeconds == 8L)
    check("Expire começa com escala 1.0 (cheio)", exhaleStart.scale == 1f)
    val exSeq = (0..7).map { BreathCycle.stateAt(11000L + it * 1000).remainingSeconds }
    check("Expire conta 8..1 $exSeq", exSeq == listOf(8L, 7L, 6L, 5L, 4L, 3L, 2L, 1L))
    check("t=18999ms ainda é Expire, remain=1", BreathCycle.stateAt(18999).let { it.phase == BreathPhase.EXPIRE && it.remainingSeconds == 1L })

    // --- escala nunca sai de [0.6, 1.0] e o meio do Inspire fica mais perto de 1.0 que do começo ---
    val allScales = (0 until 19000L step 37).map { BreathCycle.stateAt(it).scale }
    check("escala sempre entre 0.6 e 1.0", allScales.all { it in 0.6f..1.0001f })
    check("Inspire: meio (t=2000) mais cheio que início (t=0)", BreathCycle.stateAt(2000).scale > BreathCycle.stateAt(0).scale)
    check("Inspire termina perto de 1.0 (t=3999)", BreathCycle.stateAt(3999).scale > 0.99f)
    check("Expire: meio (t=15000) mais vazio que início (t=11000)", BreathCycle.stateAt(15000).scale < BreathCycle.stateAt(11000).scale)
    check("Expire termina perto de 0.6 (t=18999)", BreathCycle.stateAt(18999).scale < 0.61f)

    // --- ciclo 2 começa exatamente igual ao ciclo 1, com cycle=1 ---
    check("t=19000 volta pro Inspire com cycle=1", BreathCycle.stateAt(19000).let { it.phase == BreathPhase.INSPIRE && it.cycle == 1 })
    check("estado em t=19000 é idêntico ao de t=0 (exceto o número do ciclo)",
        BreathCycle.stateAt(19000).copy(cycle = 0) == BreathCycle.stateAt(0))
    check("cycle=0 do início até 18999ms", (0 until 19000L step 977).all { BreathCycle.stateAt(it).cycle == 0 })
    check("t=38000 é cycle=2", BreathCycle.stateAt(38000).cycle == 2)

    // --- rótulos ---
    check("rótulo Inspire", BreathCycle.phaseLabel(BreathPhase.INSPIRE) == "Inspire")
    check("rótulo Segure", BreathCycle.phaseLabel(BreathPhase.SEGURE) == "Segure")
    check("rótulo Expire", BreathCycle.phaseLabel(BreathPhase.EXPIRE) == "Expire")

    println(if (fails == 0) "\nTODOS OS TESTES PASSARAM" else "\n$fails TESTE(S) FALHARAM")
    if (fails > 0) kotlin.system.exitProcess(1)
}
